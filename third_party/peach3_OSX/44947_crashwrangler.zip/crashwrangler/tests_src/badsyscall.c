
int main() {
	syscall(0x41414141);
}